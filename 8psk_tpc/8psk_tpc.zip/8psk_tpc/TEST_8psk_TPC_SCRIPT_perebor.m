
clear;
fclose all;

load out_burst_complex_test_8psk;

% out_burst_complex
M = 8;

out_burst_complex = 1i*real(out_burst_complex)+imag(out_burst_complex);

out_burst_complex = out_burst_complex/std(out_burst_complex);

out_burst_complex_without_UWs = out_burst_complex(33:end)/std(out_burst_complex(33:end));

%data_soft_len = 4095;
data_soft_len = 4095;
num_packet_per_burst = 80;
c_r = 5;
flag_FDMA = 1;

packet_dec_len = 3249; 
frame_dec_len = packet_dec_len*num_packet_per_burst;

N=length(out_burst_complex_without_UWs);

% N = 5480;
%                 Star_=exp(1i*(0:7)*pi/4);
V=perms(0:7);
tic
parfor ind_perm=1:10000%40320
    disp(ind_perm)
    
    Star_=exp(1i*pi*V(ind_perm,:)/4)*(0.9239 + 0.3827i); % DVB_S2
    
    %Star_=exp(1i*pi*[0 1 7 6 3 2 4 5]/4)*(0.9239 + 0.3827i); % DVB_RCS2
    
    %Star_=exp(1i*pi*[0 1 3 2 7 6 4 5]/4)*(0.9239 + 0.3827i); % 1
    
    
    %Star_=exp(1i*pi*[5 4 3 2 1 0 7 6]/4)*(0.9239 + 0.3827i); % 2
    
    
    Star_ = Star_/std(Star_);
    
    %         Star=[0.923879532+0.382683432i 0.923879532-0.382683432i -0.923879532+0.382683432i -0.923879532-0.382683432i 0.382683432+0.923879532i 0.382683432-0.923879532i -0.382683432+0.923879532i -0.382683432-0.923879532i];
    %%
    
    for ind_sign = 0:1
        sign_tmp = ind_sign*2-1;
        for k = 0:3
            
            Star = Star_*exp(sign_tmp*1i*k*(pi/4));%*(0.9239 + 0.3827i); % DVB_RCS
            %      Star = Star_*exp(1i*k*(-pi/4));%*(0.9239 + 0.3827i); % DVB_RCS
            out_data_soft_now = demapDecTest_mex(out_burst_complex_without_UWs,Star,N);
            %out_data_soft_now = demapDecTest(out_burst_complex_without_UWs,Star,N);
            
            for delay = 1:1
                out_data_soft = out_data_soft_now(delay:end);
                
                %     out_data_soft = [1;out_data_soft];
                
                out_decoder_all = zeros(1,frame_dec_len);
                out_decoder_all_ = out_decoder_all;
                ind_bad_prev = 1000;
                ind_bad__prev = 1000;
                for kk = 1:num_packet_per_burst
                    %                         out_data_soft_tmp = out_data_soft;
                    %                         out_data_soft(1:2:end) = out_data_soft_tmp(2:2:end);
                    %                         out_data_soft(2:2:end) = out_data_soft_tmp(1:2:end);
                    
                    [flag_decod,~,decoded_bits] = tpc_decode([1;out_data_soft((kk-1)*data_soft_len+1:kk*data_soft_len)],c_r);
                    
                    [flag_decod_,~,decoded_bits_] = tpc_decode([1;-out_data_soft((kk-1)*data_soft_len+1:kk*data_soft_len)],c_r);
                    
                    if flag_FDMA
                        tmp_end_pos= kk*packet_dec_len;
                        tmp_start_pos = (kk-1)*packet_dec_len+1;
                        out_decoder_all(tmp_start_pos:tmp_end_pos) = decoded_bits;
                        out_decoder_all_(tmp_start_pos:tmp_end_pos) = decoded_bits_;
                        
                        bit_scrm=filter([1 0 0 1 zeros(1,16) 1],1,out_decoder_all(1:tmp_end_pos));bit_scrm=mod(bit_scrm,2);
                        %[ind_good,ind_bad] = HDLC_extract_2(1-bit_scrm);
                        [ind_good,ind_bad] = HDLC_extract_2_mex(1-bit_scrm,0);
                        
                        if ind_good||~ind_bad
                            flag_decod = 1;
%                             break;
                        end
                        
                        
                        bit_scrm=filter([1 0 0 1 zeros(1,16) 1],1,out_decoder_all_(1:tmp_end_pos));bit_scrm=mod(bit_scrm,2);
                        %[ind_good_,ind_bad_] = HDLC_extract_2(1-bit_scrm);
                        [ind_good_,ind_bad_] = HDLC_extract_2_mex(1-bit_scrm,0);
                        if ind_good_||~ind_bad_
                            flag_decod_ = 1;
                            %break;
                        end
                        
                        if (ind_bad>ind_bad_prev*1.2)&&(ind_bad_>ind_bad__prev*1.2) % TEST
                            break;
                        elseif  kk > 10
                            disp(['flag_decod_ = ' int2str(flag_decod_) '; flag_decod = ' int2str(flag_decod)...
                                'sign_tmp = ' int2str(sign_tmp) ' ;k = ' int2str(k) '; ind_perm = ' int2str(ind_perm)]);
                            keyboard();
                            
                        end
                        
                        ind_bad_prev = ind_bad;
                        ind_bad__prev = ind_bad_;
                        
                    end
                end
                
                
%                 if flag_decod||flag_decod_
%                     disp('flag_OK!');
% %                     keyboard();
%                 end
            end
            
        end
    end
end
toc