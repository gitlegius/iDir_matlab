function [set1,set1_,set2,set2_,set3,set3_]=nabory(set)
S=[0 0 0;0 0 1;0 1 0;0 1 1;1 0 0;1 0 1;1 1 0;1 1 1];
